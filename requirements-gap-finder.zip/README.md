# Requirements Gap Finder

Reads the requirement artifacts for an automation project — a PDD, an SDD and
a structured meeting summary — and surfaces the clarifying questions that
should be asked before development starts.

## The problem

Operations teams describe a process from a human point of view. The details
that don't matter to a person doing the task — exception handling, edge
cases, implicit validation, system-state assumptions — are exactly the
details automation needs, and they tend to surface mid-development rather
than during requirements gathering. Every one of them costs a rework cycle.

This tool reads the requirement documents specifically looking for that
manual-vs-automation delta, with particular attention to hedge language
("usually," "normally," "in most cases") — where the common case is described
and the uncommon one is quietly left unaddressed.

## How it works

Three documents go in: the PDD (how ops does it today), the SDD (how the
automation is designed to do it), and a meeting summary captured against a
fixed template (`prompts/meeting_summary_template.md`). A single reasoning
pass compares them and returns structured, cited questions — each with the
delta it exposes, the source document, and the quote that triggered it.

Output is typed rather than free text, so it feeds the UI and, later, the
retrieval layer directly.

## Usage

```bash
pip install -r requirements.txt
export GEMINI_API_KEY=your-key

python analyze.py                    # CLI, runs against the sample documents
streamlit run app.py                 # web UI
```

`analyze.py` accepts `--pdd`, `--sdd` and `--summary` to point at your own
documents.

The API key is read from the environment first (covering a Codespaces secret,
a shell export, or a local `.env`), falling back to Streamlit secrets for
cloud deployment.

## Layout

```
prompts/         meeting summary template used to capture requirements calls
sample_data/     example PDD, SDD and meeting summary (fictional scenario)
evaluation/      reference set of gaps, used to judge detector output
src/             gap detection and provider configuration
```

## Roadmap

- [x] Structured meeting capture template
- [x] Gap detection with cited, typed output
- [x] Web UI
- [ ] Retrieval over gap patterns from past projects, so recurring blind
      spots are checked automatically
- [ ] Feedback capture: mark which questions proved useful, log gaps found
      during development
- [ ] AWS Bedrock provider support

## Notes

Sample data describes a fictional bank and contains no real customer or
client data. Model provider is isolated to `src/llm_provider.py` so it can be
swapped without touching the rest of the codebase.
