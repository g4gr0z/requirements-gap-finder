# Expected Gaps — Reference Set

Gaps identified manually by a reviewer reading the sample PDD, SDD and
meeting summary together. Used as the reference set when judging detector
output: does it find these, and does it add anything not grounded in the
documents?

1. **Photo-of-a-photo / unreadable uploads.** The SDD routes low OCR
   confidence (<80%) to Manual Review. The meeting summary reveals ops
   currently handles this by emailing the customer for a better copy — a
   resubmission loop the SDD never designs for. Does the bot re-open the case
   when the customer re-uploads, or does "Manual Review Required" become a
   dead end requiring a human to restart the checks?
   *(SDD §5, Meeting Summary)*

2. **Name-mismatch judgement calls.** The SDD uses a 90% fuzzy-match
   threshold and treats anything below it as a failure. Ops currently uses
   human judgement for legitimate mismatches (maiden names, legal name
   changes). Should below-threshold matches always go to Manual Review, or
   does the bot need a way to accept a documented name-change reason?
   *(SDD §2.3, Meeting Summary)*

3. **Companies House vs. application form conflicts.** Both documents assume
   the comparison is a simple flag-if->25%, but neither states what happens
   when the director/PSC list itself differs between sources. Ops "normally"
   defers to Companies House, but this was never written into the design.
   Should the bot auto-resolve by trusting Companies House, or route every
   conflict to Manual Review?
   *(PDD §2.4, SDD §2.6, Meeting Summary)*

4. **MLRO escalation has no SLA or defined bot behaviour while waiting.** The
   SDD stops at status "Escalated – MLRO Review." There's no fixed queue or
   SLA on the ops side either. Does the bot poll for an MLRO decision and
   resume the case, or is escalation a one-way handoff? Determines whether
   "Escalated" is a terminal state or needs a resume path.
   *(SDD §2.8, Meeting Summary)*

5. **Weekend and off-hours submissions.** Ops works Mon–Fri 09:00–17:00 and
   weekend cases sit until Monday, but the bot polls every 15 minutes with no
   business-hours scheduling. Should the bot run only on business days, or is
   24/7 processing fine given downstream Manual Review and MLRO escalation
   are business-hours only?
   *(PDD §4, SDD §2.1)*

6. **"KYC Verified" vs "KYC Cleared".** Both terms were used for what appears
   to be the same status, but only "KYC Verified" is defined in the design.
   Confirm whether these are the same status or whether "Cleared" refers to a
   later step — writing the wrong value to the Portal status field could
   silently break a downstream integration.
   *(PDD §2.7, Meeting Summary)*

7. **Unsupported file formats vs. poor quality.** Ops mentions customers
   uploading phone photos, but neither document specifies behaviour for
   unsupported file types (e.g. HEIC) as distinct from a supported type that
   is simply low quality. These are different failure modes; only the latter
   is designed for.
   *(SDD §3, §5, Meeting Summary)*

8. **Abandoned cases.** Listed as an open item and never addressed: does a
   case in "Manual Review Required" ever time out or auto-close if the
   customer never re-uploads?
   *(Meeting Summary)*

## Evaluation notes
A useful result doesn't need all eight, but should reliably catch the
hedge-anchored ones (1, 2, 3, 7) since those carry the clearest signal, and
should cite which document each question came from. That citation is what
makes the output trustworthy enough to act on.
